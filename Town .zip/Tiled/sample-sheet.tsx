<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="city-tileset" tilewidth="8" tileheight="8" spacing="1" tilecount="360" columns="24">
 <image source="../Tilemap/tilemap.png" trans="ffaeb6" width="215" height="134"/>
</tileset>
